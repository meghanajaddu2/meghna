<?php
	while (0);
?>
<script src="./public/js/main.js"></script>
</body>
</html>