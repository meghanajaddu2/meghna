<?php
$message = 'The requested resource was not found!';
?>

<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>About Comicmailer</title>
	<link rel="stylesheet" href="./css/about.css">
</head>

<body>
	<h2><?php echo $message; ?></h2>
	<a class="link" href="index.php">Go Back</a>
</body>

</html>